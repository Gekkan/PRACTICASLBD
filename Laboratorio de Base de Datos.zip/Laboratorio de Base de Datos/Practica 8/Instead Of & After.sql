create table Sucursal1
(n_envio int,
cod_prod varchar(4),
nombre varchar(100),
Cantidad int)
go

create table Sucursal2
(n_envio int,
cod_prod varchar(4),
nombre varchar(100),
Cantidad int)
go

create table Sucursal3
(n_envio int,
cod_prod varchar(4),
nombre varchar(100),
Cantidad int)
go

create view Sucursales
as
select n_envio, cod_prod, nombre, cantidad, 'Sucursal 1' as destino from Sucursal1  
union all
select n_envio, cod_prod, nombre, cantidad, 'Sucursal 2' as destino from Sucursal2
union all
select n_envio, cod_prod, nombre, cantidad, 'Sucursal 3' as destino from Sucursal3
go

create trigger TR_Destinos2
on Sucursales instead of insert
as
set nocount on
insert into Sucursal1
select n_envio, cod_prod, nombre, cantidad from inserted where destino='Sucursal1'
insert into Sucursal2
select n_envio, cod_prod, nombre, cantidad from inserted where destino='Sucursal2'
insert into Sucursal3
select n_envio, cod_prod, nombre, cantidad from inserted where destino='Sucursal3' 
go

insert into Sucursales values(2, '1002', 'Monitor LED 17 pulgaas', 35, 'Sucursal3')
insert into Sucursales values(2, '1003', 'CABLE HDMI', 50, 'Sucursal3')
insert into Sucursales values(2, '1004', 'AIRE COMPRIMIDO', 45, 'Sucursal3')
insert into Sucursales values(2, '1005', 'PASTA TERMICA', 23, 'Sucursal3')

insert into Sucursales values(3, '1006', 'TECLADO P/TABLET', 100, 'Sucursal1')
insert into Sucursales values(4, '1007', 'FUNDA TECLADO', 230, 'Sucursal3')
insert into Sucursales values(5, '1008', 'MEMORIA MICRO SD 16GB', 700, 'Sucursal2')
go

select * from tiendas 

select * from Sucursal1
select * from Sucursal2 
select * from Sucursal3